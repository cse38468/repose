


import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class dbConnectionAdmin{

	private static final long serialVersionUID = 1L;
	private Connection con;
	static Statement st;
	static ResultSet rs;
	static String id;
	static String name;
	static String image;
	String avg;
	
	
	
	  static final String URL = "jdbc:mysql://localhost:3306/admin";
	   static final String USER = "root";
	   static final String PASSWORD = "root";
	   static final String DRIVER = "com.mysql.jdbc.Driver";
	 
	 
	   private static Connection getConnection() throws SQLException {
	      Connection con = null;
	      try {
	         Class.forName(DRIVER); 
	         con = DriverManager.getConnection(URL, USER, PASSWORD);
	      }
	      catch(ClassNotFoundException e) {
	         System.out.println(e.getMessage());
	         System.exit(-1);
	      }
	      return con;
	   }
	   

	 public String getProductName(int id) {
	       ResultSet rs;
	       try {
	          Statement s = getConnection().createStatement();
	         rs=s.executeQuery("select name from product where id="+id+"");
	          
	   			name = rs.getString("name");
	   			
	   			
	   			return name;
	      
	       }
	       catch(SQLException e) {
	          System.out.println(e.getMessage());
	          return name;
	       }
	       
	   }
	 
	 public String getProductImage(int id) {
	       ResultSet rs;
	       try {
	          Statement s = getConnection().createStatement();
	         rs=s.executeQuery("select image from product where id="+id+"");
	          
	   			image = rs.getString("image");
	   			
	   			
	   			return image;
	      
	       }
	       catch(SQLException e) {
	          System.out.println(e.getMessage());
	          return image;
	       }
	       
	   }
	 
	 
	 /*get statistika*/
	 
		public  String getRatings(int id) {
		       ResultSet rs;
		      
		       try {
		          Statement s = getConnection().createStatement();
		         rs=s.executeQuery("select AVG(rating) from review where product_id="+id+"");
		         if(rs.next()) {  // check if a result was returned
		        	 
		         
		         avg= rs.getString(1);
		         
		         }
		         return avg;
		       }
		       catch(SQLException e) {
			          System.out.println(e.getMessage());
			         return avg ;
			       }
			       
			   }    
	 
	 
	 /*insert statistika*/
	 
	 	/*		public void insertAverage() {
     
     try {
        Statement s = getConnection().createStatement();
       s.executeUpdate("INSERT INTO product()");
       	         
     }
     catch(SQLException e) {
	          System.out.println(e.getMessage());
	          System.exit(-1);
	       }
	       
	   }    
*/
	
	 
	   
	   
}
	    


