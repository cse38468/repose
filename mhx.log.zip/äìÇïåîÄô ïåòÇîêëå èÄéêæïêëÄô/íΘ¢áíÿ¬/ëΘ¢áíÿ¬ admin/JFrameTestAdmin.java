
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class JFrameTestAdmin extends JFrame {
	
	
		private static final long serialVersionUID = 1L;
		private static JFrameTestAdmin frame;
        private JPanel panelMain;
		static JPanelOneAdmin1 panel_1;
		

		static String id;
		static String name;
		static String sname;
		static String email;
		static String url;
		
				

        public JFrameTestAdmin() {

                setLayout(null);
                setPreferredSize(new Dimension(400, 610));
                setResizable(false);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                panelMain = new JPanel();
                panelMain.setBounds(0, 0, 770, 545);
                add(panelMain);

        		panel_1 = new JPanelOneAdmin1();
        		panel_1.setBounds(12, 12, 370, 594);
                panelMain.add(panel_1);
                
               
                
     		
              
pack();
        }
        
        public static void main(String[] arguments) {
        	
        	new dbConnectionAdmin();

                frame = new JFrameTestAdmin();
                frame.setVisible(true);
                frame.setTitle("��������");

        }

}