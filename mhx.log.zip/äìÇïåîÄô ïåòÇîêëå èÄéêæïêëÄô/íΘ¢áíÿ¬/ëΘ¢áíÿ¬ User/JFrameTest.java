


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JFrameTest extends JFrame {
	
	
		private static final long serialVersionUID = 1L;
		private static JFrameTest frame;
        private JPanel panelMain;
		static JPanelOne panel_1;
		static JPanelTwo panel_2;
		
		static String id;
		static String name;
		static String sname;
		static String email;
		static String url;
		static int counter=1;
		static String query;

        public JFrameTest() {

                setLayout(null);
                setPreferredSize(new Dimension(400, 610));
                setResizable(false);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                panelMain = new JPanel();
                panelMain.setBounds(0, 0, 394, 545);
                add(panelMain);

        		panel_1 = new JPanelOne();
        		panel_1.setBounds(12, 12, 370, 594);
                panelMain.add(panel_1);
                
        		panel_2 = new JPanelTwo();
        		panel_2.setBounds(12, 12, 370, 594);
                panelMain.add(panel_2);
                panel_2.setVisible(false);

pack();
        }
        
        
       
        	public static void main(String[] args) {
        		
        	
        	
        	
        	new dbConnection();
                frame = new JFrameTest();
                frame.setVisible(true);
                frame.setTitle("��������");

        }

}
