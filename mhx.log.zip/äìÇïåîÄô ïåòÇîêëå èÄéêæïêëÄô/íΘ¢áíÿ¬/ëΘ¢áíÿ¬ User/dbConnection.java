




import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class dbConnection{

	private static final long serialVersionUID = 1L;
	private Connection con;
	static Statement st;
	static ResultSet rs;
	static String id;
	static String name;
	
	static String sname;
	static String email;
	
	  static final String URL = "jdbc:mysql://localhost:3306/admin";
	   static final String USER = "root";
	   static final String PASSWORD = "root";
	   static final String DRIVER = "com.mysql.jdbc.Driver";
	 
	 
	   private static Connection getConnection() throws SQLException {
	      Connection con = null;
	      try {
	         Class.forName(DRIVER); 
	         con = DriverManager.getConnection(URL, USER, PASSWORD);
	      }
	      catch(ClassNotFoundException e) {
	         System.out.println(e.getMessage());
	         System.exit(-1);
	      }
	      return con;
	   }
	   

	 public void getNames() {
	       ResultSet rs;
	       try {
	          Statement s = getConnection().createStatement();
	         rs=s.executeQuery("select * from login1");
	          
	       while (rs.next()) {
	   			
	   			id = rs.getString("id");
	   			name = rs.getString("name");
	   			sname = rs.getString("surname");
	   			email = rs.getString("email");
	   			
	   			System.out.println(id + " " +name + " " + sname + " " + email);
	       }
	       }
	       catch(SQLException e) {
	          System.out.println(e.getMessage());
	          System.exit(-1);
	       }
	       
	   }
	 /*�������� ���������*/
	 
	 public void insertNames(String firstname,String lastname,String mail) {
	       
	       try {
	          Statement s = getConnection().createStatement();
	         s.executeUpdate("INSERT INTO login1(name,surname,email) VALUES ('"+firstname+"', '"+lastname+"', '"+mail+"')");
	         	         
	       }
	       catch(SQLException e) {
		          System.out.println(e.getMessage());
		          System.exit(-1);
		       }
		       
		   }
	
	   
	 /*�������� review*/
	 
			public void insertReview(int vathmos, String sxolia, int productid) {
	       
	       try {
	          Statement s = getConnection().createStatement();
	         s.executeUpdate("INSERT INTO review(rating,comment,product_id) VALUES ('"+vathmos+"', '"+sxolia+", '"+productid+"'')");
	         	         
	       }
	       catch(SQLException e) {
		          System.out.println(e.getMessage());
		          System.exit(-1);
		       }
		       
		   }    
	
	 
	   
}
	    



   