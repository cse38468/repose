



import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class JPanelTwo extends JPanelOne
{

	private static final long serialVersionUID = 1L;
	private JPanel panel;
	private JLabel one;
	private JRadioButton bone;
	private JLabel two;
	private JRadioButton btwo;
	private JLabel three;
	private JRadioButton bthree;
	private JLabel four;
	private JRadioButton bfour;
	private JLabel five;
	private JRadioButton bfive;
	private JLabel six;
	private JRadioButton bsix;
	private JLabel seven;
	private JRadioButton bseven;
	private JLabel eight;
	private JRadioButton beight;
	private JLabel nine;
	private JRadioButton bnine;
	private JLabel ten;
	private JRadioButton bten;
	private JButton ok;
	private JButton help;
	private JLabel eikona;
	private JComboBox type;
	private JLabel search;
	private JTextArea description;
	private JTextArea review;
	ButtonGroup bg = new ButtonGroup();
	private JLabel sxolio;
	/*private JButton post;*/
	static String typos[]={"��������...","�����������","LAPTOP","USB","BLUETOOTH","������"};
	
	static String foto[]={
		"..\\images\\desktop.png",
		"..\\images\\laptop.png",
		"..\\images\\usb.png",
		"..\\images\\bluetooth.png",
		"..\\images\\iphone.png"};
	
	static String descri[]={
		"HP,������������ IntelCore-i7 3.40 GHz, ����������� Microsoft Windows 8 ��� 64-bit,4 GB DDR3 SDRAM, 500 GB ������ ",
		"Acer V5,����� LED ����� ����,������������ Intel Core i5, ������� NVIDIA 1GB ��� ����� 1��",
		"SanDisk Usb stick 2.0 Sandisk Ultra Backup 32GB",
		"      Nokia Bluetooth Headset BH-108 Black",
		"iPhone 5 64GB,��������� ������������ �6,O���� 4'',8MP ������" } ;
	
	public JPanelTwo()
    {
    
		panel = new JPanel();
		panel.setPreferredSize(new Dimension(760, 519));
        panel.setLayout(null);
        add(panel);
    
        one = new JLabel("1");
        one.setBounds(10, 10, 10, 15);
        panel.add(one);            

        bone = new JRadioButton();
        bone.setBounds(20, 7, 20, 20);
        panel.add(bone);
        bg.add(bone);

        two = new JLabel("2");
        two.setBounds(10, 30, 10, 14);
        panel.add(two);
        
        
        btwo = new JRadioButton();
        btwo.setBounds(20, 27, 20, 20);
        panel.add(btwo);
        bg.add(btwo);

        three = new JLabel("3");
        three.setBounds(10, 50, 10, 14);
        panel.add(three);   
        
        bthree = new JRadioButton();
        bthree.setBounds(20, 47, 20, 20);
        panel.add(bthree);
        bg.add(bthree);

        four = new JLabel("4");
        four.setBounds(10, 70, 10, 14);
        panel.add(four);  
        
        bfour = new JRadioButton();
        bfour.setBounds(20, 67, 20, 20);
        panel.add(bfour);
        bg.add(bfour);

        five = new JLabel("5");
        five.setBounds(10, 90, 10, 14);
        panel.add(five); 
        
        
        bfive = new JRadioButton();
        bfive.setBounds(20, 87, 20, 20);
        panel.add(bfive);
        bg.add(bfive);

        six = new JLabel("6");
        six.setBounds(10, 110, 10, 14);
        panel.add(six);  
        
        
        bsix = new JRadioButton();
        bsix.setBounds(20, 107, 20, 20);
        panel.add(bsix);
        bg.add(bsix);

        seven = new JLabel("7");
        seven.setBounds(10, 130, 10, 14);
        panel.add(seven);
        
        bseven = new JRadioButton();
        bseven.setBounds(20, 127, 20, 20);
        panel.add(bseven);
        bg.add(bseven);

        eight = new JLabel("8");
        eight.setBounds(10, 150, 10, 14);
        panel.add(eight); 
        
        
        beight = new JRadioButton();
        beight.setBounds(20, 147, 20, 20);
        panel.add(beight);
        bg.add(beight);

        nine = new JLabel("9");
        nine.setBounds(10, 170, 10, 14);
        panel.add(nine);  
        
        bnine = new JRadioButton();
        bnine.setBounds(20, 167, 20, 20);
        panel.add(bnine);
        bg.add(bnine);

        ten = new JLabel("10");
        ten.setBounds(5, 190, 15, 14);
        panel.add(ten);
        
        bten = new JRadioButton();
        bten.setBounds(20, 187, 20, 20);
        panel.add(bten);
        bg.add(bten);
        
		ok = new JButton("����������");
		ok.setBounds(5, 220, 100, 24);
		panel.add(ok);
		
		help = new JButton("Online �������");
		help.setBounds(250, 495, 120, 20);
		panel.add(help);
		
		/*post = new JButton("POST");
		post.setBounds(290, 470, 80, 20);
		panel.add(post);*/
		
		
		eikona = new JLabel();
		eikona.setBounds(150, 30, 200, 170);
		panel.add(eikona);
		
		
		type = new JComboBox(typos);
		type.setBounds(230, 5, 130, 20);
		panel.add(type);
	
		
		 search = new JLabel("���������:");
		 search.setBounds(120, 5, 100, 20);
         panel.add(search);
         
         description = new JTextArea();
         description.setBounds(120, 210, 250, 50);
         panel.add(description);
         description.setLineWrap(true);
         description.setWrapStyleWord(true);
         description.setEditable(false);
         
         sxolio = new JLabel("������:");
         sxolio.setBounds(10, 250, 50, 50);
         panel.add(sxolio);
         
          review = new JTextArea();
          review.setLineWrap(true);
          review.setWrapStyleWord(true);
          review.setBounds(10, 290, 360, 200);
           panel.add(review);
           
           help.addActionListener(new ActionListener() {
   			private String s[] = {"������"};
   			public void actionPerformed(ActionEvent e) {
   				final JTextArea TA = new JTextArea(10,35);
   			    TA.setLineWrap(true);
   			    TA.setWrapStyleWord(true);
   			    TA.setText("�������� ��� ��������� ��� ��������� ��� ������ �������� ����������. " +
   			    		"����������� �� ������ ��� ������� ��� �� 1 �� �� 10 �� ������� ����� ��� �������� ���������� . " +
   			    		"������ ��� ����� ��� ��� �� ������");	    
   			    TA.setCaretPosition(0);
   			    TA.setEditable(false);
   			    JScrollPane sp = new JScrollPane(TA);
   				JOptionPane.showOptionDialog(null,sp,"Online �������",0,-1,null,s,s);
   			}
           });
           
         
         type.addActionListener(new ActionListener(){
       	  public void actionPerformed(ActionEvent e){
       		  if (type.getSelectedIndex() == 0) {
       			  eikona.setVisible(false);
       			  description.setVisible(false);
       			  
       		  }
       		  else if (type.getSelectedIndex() == 1) {
       			  eikona.setIcon(new ImageIcon(foto[0]));
           		  eikona.setVisible(true);
           		description.setText(descri[0]);
           		description.setVisible(true);
           		  
       		  }
       		  else if (type.getSelectedIndex() == 2) {
			  eikona.setIcon(new ImageIcon(foto[1]));
			  eikona.setVisible(true);
			  description.setText(descri[1]);
			  description.setVisible(true);
		  }
       		  else if (type.getSelectedIndex() == 3) {
       			  eikona.setIcon(new ImageIcon(foto[2]));       			  
       			  eikona.setVisible(true);
       			description.setText(descri[2]);
       			description.setVisible(true);
       		  }
       		  else if (type.getSelectedIndex() == 4) {
       			  eikona.setIcon(new ImageIcon(foto[3]));
       			  eikona.setVisible(true);
       			description.setText(descri[3]);
       			description.setVisible(true);
       		  }
       		  else if (type.getSelectedIndex() == 5) {
       			  eikona.setIcon(new ImageIcon(foto[4]));
       			  eikona.setVisible(true);
       			description.setText(descri[4]);
       			description.setVisible(true);
       		  }
       		  
       	  }
       	  
         });
         
         
         
        System.out.print(type.getSelectedIndex());
         
         
         ok.addActionListener(new ActionListener() {
 			public void actionPerformed(ActionEvent e) {
 				
 				ok.setEnabled(true);
 				int rating=Integer.parseInt(bone.getText());
	 				String comment=review.getText();
	 				
	 				int id=0;
	 				
	 				dbConnection connect = new dbConnection();
	 				System.out.print(comment);
	         		connect.insertReview(rating,comment,id);
 				
 			
 			}
 	    }); 
         
         
         
         
         
         
         
         
         
         
        }





}









