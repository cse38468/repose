

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class JPanelOne extends JPanel
{

	private static final long serialVersionUID = 1L;
	private JPanel panel;
	private JLabel name;
	private JLabel surname;
	private JLabel email;
	private JTextField text1;
	private JTextField text2;
	private JTextField text3;
	static JButton next;

	
	public JPanelOne()
    {
    
		panel = new JPanel();
        panel.setPreferredSize(new Dimension(370, 519));
        panel.setLayout(null);
        add(panel);
        
        name = new JLabel("NAME:");
        name.setBounds(5, 190, 100, 14);
        panel.add(name);
        
        surname = new JLabel("SURNAME:");
        surname.setBounds(5, 250, 100, 14);
        panel.add(surname);
        
        email = new JLabel("EMAIL:");
        email.setBounds(5, 300, 100, 14);
        panel.add(email);
    
		text1 = new JTextField();
		text1.setBounds(90, 187, 200, 20);
		panel.add(text1);
		
		
		
		text2 = new JTextField();
		text2.setBounds(90, 247, 200, 20);
		panel.add(text2);
		
		
		text3 = new JTextField();
		text3.setBounds(90, 297, 200, 20);
		panel.add(text3);
		
		

		next = new JButton("�������");
		next.setBounds(25, 350, 115, 26);
		panel.add(next);
		next.setEnabled(false);
		
        

		if (text1.getText()== null){
			next.setEnabled(true);
		}
		else if (text1.getText()!= null){
			next.setEnabled(true);
		}
		
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				next.setEnabled(true);
				String name=text1.getText();
				String surname=text2.getText();
				String email=text3.getText();
				
				dbConnection connect = new dbConnection();
				System.out.print(name);
        		connect.insertNames(name,surname,email);
				JFrameTest.panel_1.setVisible(false);
				JFrameTest.panel_2.setVisible(true);
			
			}
	    });
		
		

        }
	
	
}